# HisabSaathi — Full-Stack Production Starter

HisabSaathi is a shop-management SaaS focused on billing, inventory, customer ledger and automatic collection.

## Product rules
- No OTP/login flow.
- ₹149 / 30 days single plan.
- Bill is a simple shop receipt: no GST, CGST, SGST, IGST, HSN or GSTIN fields.
- Customer does not need to install the app.
- WhatsApp first; SMS fallback; manual call option.
- Premium is activated only after server-side payment confirmation.
- Never store card number, CVV, PIN or OTP in this application.

## Architecture
- Frontend: existing responsive HisabSaathi HTML/CSS/JS UI.
- Backend: Node.js + Express.
- Database: SQLite for the packaged starter; schema is deliberately relational and can be migrated to PostgreSQL for scale.
- Auth: random device access token issued at shop creation; token is stored server-side as SHA-256 hash. No OTP is required.
- Payments: payment gateway payment verifications when `RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET` and webhook secret are configured; otherwise safe mock mode. payment gateway payment verifications support UPI and can be created by API. The server verifies the webhook signature before activating Premium. See official docs: https://razorpay.com/docs/payments/payment-links/ and https://razorpay.com/docs/webhooks/validate-test/.
- Reminders: queued in DB and processed by `server/worker.js`. WhatsApp Cloud API is first choice; an SMS provider adapter is used as fallback when configured.

## Run locally
1. Install Node.js 20+.
2. `cp .env.example .env`
3. `npm install`
4. `npm start`
5. Open `http://localhost:3000`
6. For reminder delivery in a second terminal: `npm run worker`

## Production checklist
- Use PostgreSQL instead of SQLite for multi-instance deployment.
- Put the API behind HTTPS/reverse proxy.
- Set a strict `CORS_ORIGIN`.
- Configure payment gateway live keys and webhook secret.
- Configure WhatsApp Cloud API and an SMS fallback provider.
- Configure daily database backups and object storage for generated invoices.
- Add a proper domain, monitoring, structured logs, alerting and error tracking.
- Add a scheduled reminder policy: before due date, due date, +3 days, +7 days, then stop/slow down.
- Add rate limiting/WAF at the edge and rotate secrets periodically.
- Run security tests and dependency audits before launch.

## Core API
Public:
- `POST /api/shops`
- `GET /api/health`

Authenticated with `Authorization: Bearer <access_token>`:
- `GET/PATCH /api/shops/:id`
- `GET /api/shops/:shopId/dashboard`
- `GET /api/shops/:shopId/customers`
- `POST/PATCH /api/customers...`
- `GET /api/shops/:shopId/products`
- `POST/PATCH /api/products...`
- `POST /api/invoices`
- `GET /api/shops/:shopId/invoices`
- `POST /api/customers/:customerId/payments`
- `POST /api/subscriptions/checkout`
- `GET /api/subscriptions/status`
- `POST /api/reminders/queue`
- `GET /api/shops/:shopId/reminders`

Webhook (no app token; protected by payment gateway signature):
- `POST /api/webhooks/razorpay`

## Payment security
Do not unlock Premium from a client-side “I paid” button or screenshot. The client only displays the UPI QR and submits a payment claim. The server creates the payment order/link, stores the provider reference and activates the subscription only after a verified provider callback/webhook. payment gateway documents server-side signature verification for payment verifications and webhook HMAC verification using the raw request body.


## Payment security rule
HisabSaathi NEVER activates Premium from a frontend "I paid" button, screenshot, UTR alone, or any client-provided claim. The UTR only creates a pending verification record. Premium is activated only after a trusted server-side verification step confirms the actual ₹149 payment. Until then subscription remains inactive/pending.

## UPI subscription payment (₹149)

The subscription screen uses the supplied UPI QR:
- UPI ID: `6206769679@nyes`
- Pay exactly: `₹149`
- QR asset: `web/assets/hisabsaathi-upi-qr.jpeg`

**Security rule:** scanning/paying the QR, entering a UTR, submitting a screenshot, or clicking any client-side button never activates Premium by itself. The customer claim only becomes `pending_verification`. Premium is activated only by the protected server-side admin verification endpoint after the payment has been independently verified.

Admin verification requires `ADMIN_VERIFY_SECRET` and the `x-admin-verify-secret` header. Rejected claims never receive Premium access.


## Demo → Premium payment flow
- New users first see the full sample/demo app. Real shop data remains locked.
- The demo has a clear **₹149 Premium Unlock** action.
- Premium payment screen displays the supplied UPI QR (`6206769679@nyes`).
- Exactly ₹149 is required. A screenshot, UTR, or “I paid” claim never activates Premium.
- Customer UTR creates a `pending_verification` claim only.
- Owner/admin can review pending claims at `/admin.html` using `ADMIN_VERIFY_SECRET`. The owner must independently confirm the transaction in the UPI/bank app before approving.
- Optional `ADMIN_NOTIFICATION_WEBHOOK_URL` can send a real-time notification to an external notification service when a claim arrives.
- Automatic activation is supported architecturally through `/api/webhooks/upi-verification`, but it requires a compliant UPI/payment provider that can send a trusted success webhook. A plain static QR cannot prove that a payment happened, so QR-only mode stays manual-verification.

## Anti-fraud rules
- Exact amount check: ₹149.
- Duplicate UTR protection.
- Expiring payment orders.
- No client-side Premium activation.
- No screenshot-based approval.
- No UTR-only automatic approval.
- Premium is granted only by trusted server-side approval or a signed provider webhook.


## Production payment flow (current)

- First launch shows the full sample/demo experience.
- Real shop features are API-gated until Premium is active.
- Premium is exactly ₹149 for 30 days.
- The supplied UPI QR is bundled at `web/assets/hisabsaathi-upi-qr.jpeg` and displays UPI ID `6206769679@nyes`.
- After payment, the customer submits the UPI UTR and a payment screenshot.
- Screenshot/UTR submission **never** activates Premium and does not grant provisional access.
- The private `/admin.html` queue lets the owner inspect the proof and approve/reject. Approval activates Premium for 30 days.
- A future trusted payment-provider webhook can activate automatically, but only after server-authenticated success, exact ₹149 amount, matching order, and unique UTR. A plain QR cannot provide this trust signal by itself.
- WhatsApp owner notifications are supported through Meta WhatsApp Cloud API when `WHATSAPP_TOKEN`, `WHATSAPP_PHONE_NUMBER_ID`, and `ADMIN_WHATSAPP_TO=916206769679` are configured.

## Required environment for owner notifications

Copy `.env.example` to `.env` and set a strong `ADMIN_VERIFY_SECRET`. For WhatsApp notifications, configure a Meta WhatsApp Business account and the Cloud API token/phone-number ID. Do not put secrets in the frontend.


## Subscription / Profile-ID flow (current)

- Every shop receives a unique `profile_id` such as `HS-1A2B3C4D` at setup.
- First launch opens the full demo before asking for payment.
- Premium price is ₹149 for 30 days.
- The supplied UPI QR is bundled at `web/assets/hisabsaathi-upi-qr.jpeg`.
- After payment, the customer submits a payment screenshot and UTR/reference.
- Claim submission gives **no Premium access**. The payment stays pending until the owner approves it or a trusted payment webhook confirms the ₹149 payment.
- The screenshot, UTR, profile ID, shop name and order ID are sent to the configured admin notification channels.
- Admin can approve genuine payment for 30 days, reject it immediately, or disable/activate any profile from `/admin.html`.
- Pending payment claims remain locked until approval/rejection; expired payment orders require a new payment attempt.
- If an active 30-day subscription expires, the profile becomes expired/locked until a new payment is approved.
- A trusted payment-provider webhook can automatically convert a verified ₹149 payment into a 30-day active subscription. A static QR alone cannot prove receipt of funds.

### Admin configuration

Set these in `.env` before deployment:

- `ADMIN_VERIFY_SECRET` — private secret for `/admin.html`
- `ADMIN_WHATSAPP_TO=916206769679` — owner WhatsApp destination
- `WHATSAPP_TOKEN` and `WHATSAPP_PHONE_NUMBER_ID` — Meta WhatsApp Cloud API credentials
- `UPI_WEBHOOK_SECRET` — only if a compliant UPI/payment provider webhook is connected

The app never treats a screenshot or UTR alone as bank-confirmed payment. Screenshot submission gives only the configured 3-day provisional window; final activation is owner approval or a trusted payment webhook.
