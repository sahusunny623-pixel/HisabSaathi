import dotenv from 'dotenv';
import { db } from './db.js';
dotenv.config();

const sleep=ms=>new Promise(r=>setTimeout(r,ms));
async function sendWhatsApp(phone,message){
  if(!process.env.WHATSAPP_TOKEN||!process.env.WHATSAPP_PHONE_NUMBER_ID) throw new Error('WhatsApp provider not configured');
  const url=`https://graph.facebook.com/v23.0/${process.env.WHATSAPP_PHONE_NUMBER_ID}/messages`;
  const r=await fetch(url,{method:'POST',headers:{Authorization:`Bearer ${process.env.WHATSAPP_TOKEN}`,'Content-Type':'application/json'},body:JSON.stringify({messaging_product:'whatsapp',to:phone,type:'text',text:{body:message}})});
  const d=await r.json(); if(!r.ok) throw new Error(d?.error?.message||'WhatsApp send failed'); return d?.messages?.[0]?.id||'';
}
async function sendSms(phone,message){
  if(!process.env.SMS_PROVIDER_URL||!process.env.SMS_PROVIDER_TOKEN) throw new Error('SMS provider not configured');
  const r=await fetch(process.env.SMS_PROVIDER_URL,{method:'POST',headers:{Authorization:`Bearer ${process.env.SMS_PROVIDER_TOKEN}`,'Content-Type':'application/json'},body:JSON.stringify({to:phone,message})});
  if(!r.ok) throw new Error('SMS send failed'); const d=await r.json().catch(()=>({})); return d?.request_id||'';
}
async function processBatch(){
  const rows=db.prepare(`SELECT r.*,c.name,c.phone,c.credit_balance,s.name shop_name FROM reminders r JOIN customers c ON c.id=r.customer_id JOIN shops s ON s.id=r.shop_id WHERE r.status='queued' AND datetime(r.scheduled_for)<=datetime('now') AND c.credit_balance>0 ORDER BY r.scheduled_for LIMIT 50`).all();
  for(const r of rows){
    try{
      if(r.channel==='call'){db.prepare(`UPDATE reminders SET status='manual_required' WHERE id=?`).run(r.id);continue;}
      const message=`Namaste ${r.name}, ${r.shop_name} ki taraf se ₹${r.credit_balance.toLocaleString('en-IN')} ki udhaari baaki hai. Kripya payment kar dein. Dhanyavaad 🙏`;
      let ref='';
      if(r.channel==='whatsapp'){try{ref=await sendWhatsApp(r.phone,message);}catch{if(process.env.SMS_PROVIDER_URL) {ref=await sendSms(r.phone,message);db.prepare(`UPDATE reminders SET channel='sms' WHERE id=?`).run(r.id);}else throw new Error('WhatsApp failed and SMS fallback is not configured');}}
      else ref=await sendSms(r.phone,message);
      db.prepare(`UPDATE reminders SET status='sent',sent_at=CURRENT_TIMESTAMP,provider_ref=? WHERE id=?`).run(ref,r.id);
    }catch(e){db.prepare(`UPDATE reminders SET status='failed' WHERE id=?`).run(r.id);console.error('Reminder',r.id,e.message);}
  }
}
console.log('HisabSaathi reminder worker started');
while(true){await processBatch();await sleep(Number(process.env.WORKER_INTERVAL_MS||60000));}
